#ifndef SIMULATE_H
#define SIMULATE_H

int simulate(int steps);

#endif