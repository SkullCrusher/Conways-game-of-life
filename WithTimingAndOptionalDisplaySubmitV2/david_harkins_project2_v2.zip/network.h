#ifndef Network_H
#define Network_H

	// Take the argument seed and create new ones for every node.
int PropagateSeed(int seed);

	// Print out the matrix for the game of life.
void DisplayGoL(int N);

#endif