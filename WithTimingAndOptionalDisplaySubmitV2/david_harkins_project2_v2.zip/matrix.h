#ifndef Matrix_H
#define Matrix_H

	// Generate the local matrix.
int GenerateInitialGoL(int Seed, int NdivideByP, int N);

	// Clean up the local matrix.
void CleanupMatrix(int n);

#endif
